package dev.alexmahon.position_book_system.enums;

public enum TradeEventAction {
    BUY,
    CANCEL,
    SELL
}
