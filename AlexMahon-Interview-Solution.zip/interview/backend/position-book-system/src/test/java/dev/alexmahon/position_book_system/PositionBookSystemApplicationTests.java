package dev.alexmahon.position_book_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PositionBookSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
