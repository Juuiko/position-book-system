import { createContext, useContext, useState } from "react";

const RefreshContext = createContext<{ refresh: () => void }>({ refresh: () => {} });

export function AdminProvider({ children }: { children: React.ReactNode }) {
  const [refreshKey, setRefreshKey] = useState(0);
  return (
    <RefreshContext.Provider value={{ refresh: () => setRefreshKey(k => k + 1) }}>
      <div key={refreshKey}>{children}</div>
    </RefreshContext.Provider>
  );
}

export function useRefresh() {
  return useContext(RefreshContext);
}