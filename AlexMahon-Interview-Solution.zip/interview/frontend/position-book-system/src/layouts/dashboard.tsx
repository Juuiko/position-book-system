import { Outlet } from "react-router";
import { AppSidebar } from "../components/sidebar/sidebar";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";
import { EventFormProvider } from "@/context/create-event-form-provider";
import { AdminProvider } from "@/context/admin-provider";

export default function Dashboard() {
  return (
    <div>
      <AdminProvider>
        <SidebarProvider>
          <EventFormProvider>
            <AppSidebar />
            <SidebarInset>
              <Outlet />
            </SidebarInset>
          </EventFormProvider>
        </SidebarProvider>
      </AdminProvider>
    </div>
  );
}
