import { Settings } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SidebarMenuButton } from "../ui/sidebar";
import { getClearDatabase, postPopulateDatabase } from "@/api/admin-calls";
import { useRefresh } from "@/context/admin-provider";

export function AdminDialog() {
  const { refresh } = useRefresh();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <SidebarMenuButton>
          <Settings />
          <span>Admin Actions</span>
        </SidebarMenuButton>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem
          onClick={() => {
            getClearDatabase().then(refresh);
          }}
        >
          Clear Database
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => {
            postPopulateDatabase().then(refresh);
          }}
        >
          Populate Database
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
